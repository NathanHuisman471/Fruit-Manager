﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fruit_Manager_V1._0
{
    public class u1
    {
        string name;
        string password;
    }

    
}
