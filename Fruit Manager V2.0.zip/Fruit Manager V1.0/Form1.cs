﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fruit_Manager_V1._0
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        public static class u1
        {
            public const string name = "Jimmy";
            public const string password = "Johns";
        }

        public void label1_Click(object sender, EventArgs e)
        {
           
        }

        private void UserButton_Click(object sender, EventArgs e)
        {
            var newForm = new Credentials();
            newForm.Show();
            label1.Text = "Jimmy John";
        }

        private void Slabel_Click(object sender, EventArgs e)
        {

        }

        private void Cash_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Total_Click(object sender, EventArgs e)
        {

        }
    }
}
