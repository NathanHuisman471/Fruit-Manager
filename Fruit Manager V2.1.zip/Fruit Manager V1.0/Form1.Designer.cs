﻿namespace Fruit_Manager_V1._0
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.UserButton = new System.Windows.Forms.Button();
            this.RedApples = new System.Windows.Forms.Button();
            this.GoldenApples = new System.Windows.Forms.Button();
            this.Tangerines = new System.Windows.Forms.Button();
            this.Clemitines = new System.Windows.Forms.Button();
            this.Pears = new System.Windows.Forms.Button();
            this.SmallMix = new System.Windows.Forms.Button();
            this.LargeMix = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.RAlabel = new System.Windows.Forms.Label();
            this.GAlabel = new System.Windows.Forms.Label();
            this.Tlabel = new System.Windows.Forms.Label();
            this.Clabel = new System.Windows.Forms.Label();
            this.Plabel = new System.Windows.Forms.Label();
            this.Slabel = new System.Windows.Forms.Label();
            this.Llabel = new System.Windows.Forms.Label();
            this.Cash = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.check = new System.Windows.Forms.CheckBox();
            this.None = new System.Windows.Forms.CheckBox();
            this.EnterSale = new System.Windows.Forms.Button();
            this.CancelSale = new System.Windows.Forms.Button();
            this.CurrentTotal = new System.Windows.Forms.Label();
            this.Total = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "User";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // UserButton
            // 
            this.UserButton.Location = new System.Drawing.Point(22, 49);
            this.UserButton.Name = "UserButton";
            this.UserButton.Size = new System.Drawing.Size(102, 37);
            this.UserButton.TabIndex = 1;
            this.UserButton.Text = "User";
            this.UserButton.UseVisualStyleBackColor = true;
            this.UserButton.Click += new System.EventHandler(this.UserButton_Click);
            // 
            // RedApples
            // 
            this.RedApples.Location = new System.Drawing.Point(62, 196);
            this.RedApples.Name = "RedApples";
            this.RedApples.Size = new System.Drawing.Size(117, 62);
            this.RedApples.TabIndex = 2;
            this.RedApples.Text = "Red Apples";
            this.RedApples.UseVisualStyleBackColor = true;
            this.RedApples.Click += new System.EventHandler(this.RedApples_Click);
            // 
            // GoldenApples
            // 
            this.GoldenApples.Location = new System.Drawing.Point(264, 196);
            this.GoldenApples.Name = "GoldenApples";
            this.GoldenApples.Size = new System.Drawing.Size(117, 62);
            this.GoldenApples.TabIndex = 3;
            this.GoldenApples.Text = "Golden Apples";
            this.GoldenApples.UseVisualStyleBackColor = true;
            this.GoldenApples.Click += new System.EventHandler(this.GoldenApples_Click);
            // 
            // Tangerines
            // 
            this.Tangerines.Location = new System.Drawing.Point(453, 196);
            this.Tangerines.Name = "Tangerines";
            this.Tangerines.Size = new System.Drawing.Size(117, 62);
            this.Tangerines.TabIndex = 4;
            this.Tangerines.Text = "Tangerines";
            this.Tangerines.UseVisualStyleBackColor = true;
            this.Tangerines.Click += new System.EventHandler(this.Tangerines_Click);
            // 
            // Clemitines
            // 
            this.Clemitines.Location = new System.Drawing.Point(650, 196);
            this.Clemitines.Name = "Clemitines";
            this.Clemitines.Size = new System.Drawing.Size(117, 62);
            this.Clemitines.TabIndex = 5;
            this.Clemitines.Text = "Clemitines";
            this.Clemitines.UseVisualStyleBackColor = true;
            this.Clemitines.Click += new System.EventHandler(this.Clemitines_Click);
            // 
            // Pears
            // 
            this.Pears.Location = new System.Drawing.Point(62, 334);
            this.Pears.Name = "Pears";
            this.Pears.Size = new System.Drawing.Size(117, 62);
            this.Pears.TabIndex = 6;
            this.Pears.Text = "Pears";
            this.Pears.UseVisualStyleBackColor = true;
            this.Pears.Click += new System.EventHandler(this.Pears_Click);
            // 
            // SmallMix
            // 
            this.SmallMix.Location = new System.Drawing.Point(264, 334);
            this.SmallMix.Name = "SmallMix";
            this.SmallMix.Size = new System.Drawing.Size(117, 62);
            this.SmallMix.TabIndex = 7;
            this.SmallMix.Text = "Small Mix Box";
            this.SmallMix.UseVisualStyleBackColor = true;
            this.SmallMix.Click += new System.EventHandler(this.SmallMix_Click);
            // 
            // LargeMix
            // 
            this.LargeMix.Location = new System.Drawing.Point(453, 334);
            this.LargeMix.Name = "LargeMix";
            this.LargeMix.Size = new System.Drawing.Size(117, 62);
            this.LargeMix.TabIndex = 8;
            this.LargeMix.Text = "Large Mix Box";
            this.LargeMix.UseVisualStyleBackColor = true;
            this.LargeMix.Click += new System.EventHandler(this.LargeMix_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(224, 49);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(543, 22);
            this.textBox1.TabIndex = 9;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(224, 110);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(543, 22);
            this.textBox2.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(221, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 17);
            this.label2.TabIndex = 11;
            this.label2.Text = "Customer Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(221, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 17);
            this.label3.TabIndex = 12;
            this.label3.Text = "Contact Information";
            // 
            // RAlabel
            // 
            this.RAlabel.AutoSize = true;
            this.RAlabel.Location = new System.Drawing.Point(108, 176);
            this.RAlabel.Name = "RAlabel";
            this.RAlabel.Size = new System.Drawing.Size(16, 17);
            this.RAlabel.TabIndex = 13;
            this.RAlabel.Text = "0";
            this.RAlabel.Click += new System.EventHandler(this.RAlabel_Click);
            // 
            // GAlabel
            // 
            this.GAlabel.AutoSize = true;
            this.GAlabel.Location = new System.Drawing.Point(314, 176);
            this.GAlabel.Name = "GAlabel";
            this.GAlabel.Size = new System.Drawing.Size(16, 17);
            this.GAlabel.TabIndex = 14;
            this.GAlabel.Text = "0";
            this.GAlabel.Click += new System.EventHandler(this.GAlabel_Click);
            // 
            // Tlabel
            // 
            this.Tlabel.AutoSize = true;
            this.Tlabel.Location = new System.Drawing.Point(503, 176);
            this.Tlabel.Name = "Tlabel";
            this.Tlabel.Size = new System.Drawing.Size(16, 17);
            this.Tlabel.TabIndex = 15;
            this.Tlabel.Text = "0";
            // 
            // Clabel
            // 
            this.Clabel.AutoSize = true;
            this.Clabel.Location = new System.Drawing.Point(701, 176);
            this.Clabel.Name = "Clabel";
            this.Clabel.Size = new System.Drawing.Size(16, 17);
            this.Clabel.TabIndex = 16;
            this.Clabel.Text = "0";
            // 
            // Plabel
            // 
            this.Plabel.AutoSize = true;
            this.Plabel.Location = new System.Drawing.Point(108, 314);
            this.Plabel.Name = "Plabel";
            this.Plabel.Size = new System.Drawing.Size(16, 17);
            this.Plabel.TabIndex = 17;
            this.Plabel.Text = "0";
            // 
            // Slabel
            // 
            this.Slabel.AutoSize = true;
            this.Slabel.Location = new System.Drawing.Point(314, 314);
            this.Slabel.Name = "Slabel";
            this.Slabel.Size = new System.Drawing.Size(16, 17);
            this.Slabel.TabIndex = 18;
            this.Slabel.Text = "0";
            this.Slabel.Click += new System.EventHandler(this.Slabel_Click);
            // 
            // Llabel
            // 
            this.Llabel.AutoSize = true;
            this.Llabel.Location = new System.Drawing.Point(503, 314);
            this.Llabel.Name = "Llabel";
            this.Llabel.Size = new System.Drawing.Size(16, 17);
            this.Llabel.TabIndex = 19;
            this.Llabel.Text = "0";
            // 
            // Cash
            // 
            this.Cash.AutoSize = true;
            this.Cash.Location = new System.Drawing.Point(264, 473);
            this.Cash.Name = "Cash";
            this.Cash.Size = new System.Drawing.Size(62, 21);
            this.Cash.TabIndex = 24;
            this.Cash.Text = "Cash";
            this.Cash.UseVisualStyleBackColor = true;
            this.Cash.CheckedChanged += new System.EventHandler(this.Cash_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(59, 477);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 17);
            this.label4.TabIndex = 20;
            this.label4.Text = "Payment Method:";
            // 
            // check
            // 
            this.check.AutoSize = true;
            this.check.Location = new System.Drawing.Point(453, 476);
            this.check.Name = "check";
            this.check.Size = new System.Drawing.Size(69, 21);
            this.check.TabIndex = 25;
            this.check.Text = "Check";
            this.check.UseVisualStyleBackColor = true;
            // 
            // None
            // 
            this.None.AutoSize = true;
            this.None.Location = new System.Drawing.Point(650, 473);
            this.None.Name = "None";
            this.None.Size = new System.Drawing.Size(53, 21);
            this.None.TabIndex = 26;
            this.None.Text = "N/A";
            this.None.UseVisualStyleBackColor = true;
            // 
            // EnterSale
            // 
            this.EnterSale.Location = new System.Drawing.Point(850, 196);
            this.EnterSale.Name = "EnterSale";
            this.EnterSale.Size = new System.Drawing.Size(125, 244);
            this.EnterSale.TabIndex = 27;
            this.EnterSale.Text = "Enter Sale";
            this.EnterSale.UseVisualStyleBackColor = true;
            // 
            // CancelSale
            // 
            this.CancelSale.Location = new System.Drawing.Point(650, 334);
            this.CancelSale.Name = "CancelSale";
            this.CancelSale.Size = new System.Drawing.Size(123, 62);
            this.CancelSale.TabIndex = 28;
            this.CancelSale.Text = "Cancel Sale";
            this.CancelSale.UseVisualStyleBackColor = true;
            this.CancelSale.Click += new System.EventHandler(this.CancelSale_Click);
            // 
            // CurrentTotal
            // 
            this.CurrentTotal.AutoSize = true;
            this.CurrentTotal.Location = new System.Drawing.Point(864, 49);
            this.CurrentTotal.Name = "CurrentTotal";
            this.CurrentTotal.Size = new System.Drawing.Size(91, 17);
            this.CurrentTotal.TabIndex = 29;
            this.CurrentTotal.Text = "Current Total";
            // 
            // Total
            // 
            this.Total.AutoSize = true;
            this.Total.Location = new System.Drawing.Point(898, 110);
            this.Total.Name = "Total";
            this.Total.Size = new System.Drawing.Size(16, 17);
            this.Total.TabIndex = 30;
            this.Total.Text = "0";
            this.Total.Click += new System.EventHandler(this.Total_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1039, 553);
            this.Controls.Add(this.Total);
            this.Controls.Add(this.CurrentTotal);
            this.Controls.Add(this.CancelSale);
            this.Controls.Add(this.EnterSale);
            this.Controls.Add(this.None);
            this.Controls.Add(this.check);
            this.Controls.Add(this.Cash);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Llabel);
            this.Controls.Add(this.Slabel);
            this.Controls.Add(this.Plabel);
            this.Controls.Add(this.Clabel);
            this.Controls.Add(this.Tlabel);
            this.Controls.Add(this.GAlabel);
            this.Controls.Add(this.RAlabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.LargeMix);
            this.Controls.Add(this.SmallMix);
            this.Controls.Add(this.Pears);
            this.Controls.Add(this.Clemitines);
            this.Controls.Add(this.Tangerines);
            this.Controls.Add(this.GoldenApples);
            this.Controls.Add(this.RedApples);
            this.Controls.Add(this.UserButton);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button UserButton;
        private System.Windows.Forms.Button RedApples;
        private System.Windows.Forms.Button GoldenApples;
        private System.Windows.Forms.Button Tangerines;
        private System.Windows.Forms.Button Clemitines;
        private System.Windows.Forms.Button Pears;
        private System.Windows.Forms.Button SmallMix;
        private System.Windows.Forms.Button LargeMix;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label RAlabel;
        private System.Windows.Forms.Label GAlabel;
        private System.Windows.Forms.Label Tlabel;
        private System.Windows.Forms.Label Clabel;
        private System.Windows.Forms.Label Plabel;
        private System.Windows.Forms.Label Slabel;
        private System.Windows.Forms.Label Llabel;
        private System.Windows.Forms.CheckBox Cash;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox check;
        private System.Windows.Forms.CheckBox None;
        private System.Windows.Forms.Button EnterSale;
        private System.Windows.Forms.Button CancelSale;
        private System.Windows.Forms.Label CurrentTotal;
        private System.Windows.Forms.Label Total;
    }
}

