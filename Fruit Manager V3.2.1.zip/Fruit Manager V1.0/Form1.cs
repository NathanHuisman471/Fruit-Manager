﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fruit_Manager_V1._0
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }
        public int runningTotal = 0;
        int redAppleRunningTotal = 0;
        int goldenAppleRunningTotal = 0;
        int tangerineRunningTotal = 0;
        int clemitinesRunningTotal = 0;
        int pearsRunningTotal = 0;
        int smallBoxRunningTotal = 0;
        int largeBoxRunningTotal = 0;

        public int entryNumber = 0;

        public static class u1
        {
            public const string name = "Jimmy";
            public const string password = "Johns";
        }

        public void label1_Click(object sender, EventArgs e)
        {
           
        }

        private void UserButton_Click(object sender, EventArgs e)
        {
            var newForm = new Credentials();
            newForm.Show();
            label1.Text = "Jimmy John";
        }

        private void Slabel_Click(object sender, EventArgs e)
        {

        }

        private void Cash_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Total_Click(object sender, EventArgs e)
        {

        }

        private void RAlabel_Click(object sender, EventArgs e)
        {

        }

        private void RedApples_Click(object sender, EventArgs e)
        {
            redAppleRunningTotal++;
            string myString = redAppleRunningTotal.ToString();
            RAlabel.Text = myString;
            runningTotal = runningTotal + 32;
            string myString2 = runningTotal.ToString();
            Total.Text = myString2;
        }

        private void GAlabel_Click(object sender, EventArgs e)
        {

        }

        private void GoldenApples_Click(object sender, EventArgs e)
        {
            goldenAppleRunningTotal++;
            string myString = goldenAppleRunningTotal.ToString();
            GAlabel.Text = myString;
            runningTotal = runningTotal + 34;
            string myString2 = runningTotal.ToString();
            Total.Text = myString2;
        }

        private void Tangerines_Click(object sender, EventArgs e)
        {
            tangerineRunningTotal++;
            string myString = tangerineRunningTotal.ToString();
            Tlabel.Text = myString;
            runningTotal = runningTotal + 40;
            string myString2 = runningTotal.ToString();
            Total.Text = myString2;
        }

        private void Clemitines_Click(object sender, EventArgs e)
        {
            clemitinesRunningTotal++;
            string myString = clemitinesRunningTotal.ToString();
            Clabel.Text = myString;
            runningTotal = runningTotal + 14;
            string myString2 = runningTotal.ToString();
            Total.Text = myString2;
        }

        private void Pears_Click(object sender, EventArgs e)
        {
            pearsRunningTotal++;
            string myString = pearsRunningTotal.ToString();
            Plabel.Text = myString;
            runningTotal = runningTotal + 30;
            string myString2 = runningTotal.ToString();
            Total.Text = myString2;
        }

        private void SmallMix_Click(object sender, EventArgs e)
        {
            smallBoxRunningTotal++;
            string myString = smallBoxRunningTotal.ToString();
            Slabel.Text = myString;
            runningTotal = runningTotal + 24;
            string myString2 = runningTotal.ToString();
            Total.Text = myString2;
        }

        private void LargeMix_Click(object sender, EventArgs e)
        {
            largeBoxRunningTotal++;
            string myString = largeBoxRunningTotal.ToString();
            Llabel.Text = myString;
            runningTotal = runningTotal + 36;
            string myString2 = runningTotal.ToString();
            Total.Text = myString2;
        }


        private void CancelSale_Click(object sender, EventArgs e)
        {
            //set all sale values to 0
            runningTotal = 0;
            redAppleRunningTotal = 0;
            goldenAppleRunningTotal = 0;
            tangerineRunningTotal = 0;
            clemitinesRunningTotal = 0;
            pearsRunningTotal = 0;
            smallBoxRunningTotal = 0;
            largeBoxRunningTotal = 0;

            //clear text boxes
            textBox1.Text = "";
            textBox2.Text = "";

            //display 0 in all labels
            RAlabel.Text = "0";
            GAlabel.Text = "0";
            Tlabel.Text = "0";
            Clabel.Text = "0";
            Plabel.Text = "0";
            Slabel.Text = "0";
            Llabel.Text = "0";
            Total.Text = "0";
        }

        private void EnterSale_Click(object sender, EventArgs e)
        {
            entryNumber++;
            // do the thing
            if(entryNumber == 1)
            {
                string myString = textBox1.Text.ToString();
                Reports.customer[entryNumber] = myString;
            }


            //set all sale values to 0
            runningTotal = 0;
            redAppleRunningTotal = 0;
            goldenAppleRunningTotal = 0;
            tangerineRunningTotal = 0;
            clemitinesRunningTotal = 0;
            pearsRunningTotal = 0;
            smallBoxRunningTotal = 0;
            largeBoxRunningTotal = 0;

            //clear text boxes
            textBox1.Text = "";
            textBox2.Text = "";

            //display 0 in all labels
            RAlabel.Text = "0";
            GAlabel.Text = "0";
            Tlabel.Text = "0";
            Clabel.Text = "0";
            Plabel.Text = "0";
            Slabel.Text = "0";
            Llabel.Text = "0";
            Total.Text = "0";
        }

        private void ShowReport_Click(object sender, EventArgs e)
        {
            var newForm = new Reports();
            newForm.Show();
        }
    }
}
