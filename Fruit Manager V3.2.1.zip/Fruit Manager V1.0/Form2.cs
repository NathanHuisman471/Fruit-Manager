﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fruit_Manager_V1._0
{
    public partial class Reports : Form3
    {
        //passing of Variables
        public static string[] customer = new string[5];
        public static string customer2;
        public static string customer3;
        public static string customer4;
        public static string customer5;
        public static string ra1;
        public static string ra2;
        public static string ra3;
        public static string ra4;
        public static string ra5;
        public static string rat;
        public static string ga1;
        public static string ga2;
        public static string ga3;
        public static string ga4;
        public static string ga5;
        public static string gat;
        public static string c1;
        public static string c2;
        public static string c3;
        public static string c4;
        public static string c5;
        public static string ct;

        public Reports()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Customer1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            for(int i=1; i<=5; i++)
            {

                if(i == 1)
                {
                    string myString = customer[1].ToString();
                    Customer1.Text = myString;
                }
                
            }
        }
    }
}
