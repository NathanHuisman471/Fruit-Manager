﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fruit_Manager_V1._0
{
    public partial class Reports : Form3
    {
        public static int entryNumber = 0;
        //passing of Variables
        public static string[] customer = new string[5];
        public static string[] ra = new string[6];
        public static string[] ga = new string[6];
        public static string[] t = new string[6];
        public static string[] c = new string[6];
        public static string[] p = new string[6];
        public static string[] s = new string[6];
        public static string[] l = new string[6];

        public Reports()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Customer1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            for(int i=1; i<= entryNumber; i++)
            {

                if(i == 1)
                {
                    string myString = customer[i].ToString();
                    Customer1.Text = myString;
                    string myString2 = ra[i].ToString();
                    RA1.Text = myString2;
                    string myString3 = ga[i].ToString();
                    GA1.Text = myString3;
                    string myString4 = t[i].ToString();
                    T1.Text = myString4;
                    string myString5 = c[i].ToString();
                    C1.Text = myString5;
                    string myString6 = p[i].ToString();
                    P1.Text = myString6;
                    string myString7 = s[i].ToString();
                    S1.Text = myString7;
                    string myString8 = l[i].ToString();
                    L1.Text = myString8;

                }
                else if (i == 2)
                {
                    string myString = customer[i].ToString();
                    Customer2.Text = myString;
                    string myString2 = ra[i].ToString();
                    RA2.Text = myString2;
                    string myString3 = ga[i].ToString();
                    GA2.Text = myString3;
                    string myString4 = t[i].ToString();
                    T2.Text = myString4;
                    string myString5 = c[i].ToString();
                    C2.Text = myString5;
                    string myString6 = p[i].ToString();
                    P2.Text = myString6;
                    string myString7 = s[i].ToString();
                    S2.Text = myString7;
                    string myString8 = l[i].ToString();
                    L2.Text = myString8;
                }
                else if (i == 3)
                {
                    string myString = customer[i].ToString();
                    Customer3.Text = myString;
                    string myString2 = ra[i].ToString();
                    RA3.Text = myString2;
                    string myString3 = ga[i].ToString();
                    GA3.Text = myString3;
                    string myString4 = t[i].ToString();
                    T3.Text = myString4;
                    string myString5 = c[i].ToString();
                    C3.Text = myString5;
                    string myString6 = p[i].ToString();
                    P3.Text = myString6;
                    string myString7 = s[i].ToString();
                    S3.Text = myString7;
                    string myString8 = l[i].ToString();
                    L3.Text = myString8;
                }
                else if (i == 4)
                {
                    string myString = customer[i].ToString();
                    Customer4.Text = myString;
                    string myString2 = ra[i].ToString();
                    RA4.Text = myString2;
                    string myString3 = ga[i].ToString();
                    GA4.Text = myString3;
                    string myString4 = t[i].ToString();
                    T4.Text = myString4;
                    string myString5 = c[i].ToString();
                    C4.Text = myString5;
                    string myString6 = p[i].ToString();
                    P4.Text = myString6;
                    string myString7 = s[i].ToString();
                    S4.Text = myString7;
                    string myString8 = l[i].ToString();
                    L4.Text = myString8;
                }
                else if (i == 5)
                {
                    string myString = customer[i].ToString();
                    Customer5.Text = myString;
                    string myString2 = ra[i].ToString();
                    RA5.Text = myString2;
                    string myString3 = ga[i].ToString();
                    GA5.Text = myString3;
                    string myString4 = t[i].ToString();
                    T5.Text = myString4;
                    string myString5 = c[i].ToString();
                    C5.Text = myString5;
                    string myString6 = p[i].ToString();
                    P5.Text = myString6;
                    string myString7 = s[i].ToString();
                    S5.Text = myString7;
                    string myString8 = l[i].ToString();
                    L5.Text = myString8;
                }
            }
        }
    }
}
