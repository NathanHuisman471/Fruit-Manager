﻿namespace Fruit_Manager_V1._0
{
    partial class Reports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Customer1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.RA1 = new System.Windows.Forms.Label();
            this.GA1 = new System.Windows.Forms.Label();
            this.T1 = new System.Windows.Forms.Label();
            this.C1 = new System.Windows.Forms.Label();
            this.P1 = new System.Windows.Forms.Label();
            this.S1 = new System.Windows.Forms.Label();
            this.L1 = new System.Windows.Forms.Label();
            this.L2 = new System.Windows.Forms.Label();
            this.S2 = new System.Windows.Forms.Label();
            this.P2 = new System.Windows.Forms.Label();
            this.C2 = new System.Windows.Forms.Label();
            this.T2 = new System.Windows.Forms.Label();
            this.GA2 = new System.Windows.Forms.Label();
            this.RA2 = new System.Windows.Forms.Label();
            this.Customer2 = new System.Windows.Forms.Label();
            this.L3 = new System.Windows.Forms.Label();
            this.S3 = new System.Windows.Forms.Label();
            this.P3 = new System.Windows.Forms.Label();
            this.C3 = new System.Windows.Forms.Label();
            this.T3 = new System.Windows.Forms.Label();
            this.GA3 = new System.Windows.Forms.Label();
            this.RA3 = new System.Windows.Forms.Label();
            this.Customer3 = new System.Windows.Forms.Label();
            this.L4 = new System.Windows.Forms.Label();
            this.S4 = new System.Windows.Forms.Label();
            this.P4 = new System.Windows.Forms.Label();
            this.C4 = new System.Windows.Forms.Label();
            this.T4 = new System.Windows.Forms.Label();
            this.GA4 = new System.Windows.Forms.Label();
            this.RA4 = new System.Windows.Forms.Label();
            this.Customer4 = new System.Windows.Forms.Label();
            this.L5 = new System.Windows.Forms.Label();
            this.S5 = new System.Windows.Forms.Label();
            this.P5 = new System.Windows.Forms.Label();
            this.C5 = new System.Windows.Forms.Label();
            this.T5 = new System.Windows.Forms.Label();
            this.GA5 = new System.Windows.Forms.Label();
            this.RA5 = new System.Windows.Forms.Label();
            this.Customer5 = new System.Windows.Forms.Label();
            this.LT = new System.Windows.Forms.Label();
            this.ST = new System.Windows.Forms.Label();
            this.PT = new System.Windows.Forms.Label();
            this.CT = new System.Windows.Forms.Label();
            this.TT = new System.Windows.Forms.Label();
            this.GAT = new System.Windows.Forms.Label();
            this.RAT = new System.Windows.Forms.Label();
            this.CustomerTotal = new System.Windows.Forms.Label();
            this.Info1 = new System.Windows.Forms.Label();
            this.Info2 = new System.Windows.Forms.Label();
            this.Info3 = new System.Windows.Forms.Label();
            this.Info4 = new System.Windows.Forms.Label();
            this.Info5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Customer1
            // 
            this.Customer1.AccessibleName = "Customer1";
            this.Customer1.AutoSize = true;
            this.Customer1.Location = new System.Drawing.Point(75, 100);
            this.Customer1.Name = "Customer1";
            this.Customer1.Size = new System.Drawing.Size(46, 17);
            this.Customer1.TabIndex = 0;
            this.Customer1.Text = "label1";
            this.Customer1.Click += new System.EventHandler(this.Customer1_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(968, 480);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // RA1
            // 
            this.RA1.AccessibleName = "Customer1";
            this.RA1.AutoSize = true;
            this.RA1.Location = new System.Drawing.Point(200, 100);
            this.RA1.Name = "RA1";
            this.RA1.Size = new System.Drawing.Size(46, 17);
            this.RA1.TabIndex = 2;
            this.RA1.Text = "label1";
            // 
            // GA1
            // 
            this.GA1.AccessibleName = "Customer1";
            this.GA1.AutoSize = true;
            this.GA1.Location = new System.Drawing.Point(300, 100);
            this.GA1.Name = "GA1";
            this.GA1.Size = new System.Drawing.Size(46, 17);
            this.GA1.TabIndex = 3;
            this.GA1.Text = "label1";
            // 
            // T1
            // 
            this.T1.AccessibleName = "Customer1";
            this.T1.AutoSize = true;
            this.T1.Location = new System.Drawing.Point(400, 100);
            this.T1.Name = "T1";
            this.T1.Size = new System.Drawing.Size(46, 17);
            this.T1.TabIndex = 4;
            this.T1.Text = "label1";
            // 
            // C1
            // 
            this.C1.AccessibleName = "Customer1";
            this.C1.AutoSize = true;
            this.C1.Location = new System.Drawing.Point(500, 100);
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(46, 17);
            this.C1.TabIndex = 5;
            this.C1.Text = "label1";
            // 
            // P1
            // 
            this.P1.AccessibleName = "Customer1";
            this.P1.AutoSize = true;
            this.P1.Location = new System.Drawing.Point(600, 100);
            this.P1.Name = "P1";
            this.P1.Size = new System.Drawing.Size(46, 17);
            this.P1.TabIndex = 6;
            this.P1.Text = "label1";
            // 
            // S1
            // 
            this.S1.AccessibleName = "Customer1";
            this.S1.AutoSize = true;
            this.S1.Location = new System.Drawing.Point(700, 100);
            this.S1.Name = "S1";
            this.S1.Size = new System.Drawing.Size(46, 17);
            this.S1.TabIndex = 7;
            this.S1.Text = "label1";
            // 
            // L1
            // 
            this.L1.AccessibleName = "Customer1";
            this.L1.AutoSize = true;
            this.L1.Location = new System.Drawing.Point(800, 100);
            this.L1.Name = "L1";
            this.L1.Size = new System.Drawing.Size(46, 17);
            this.L1.TabIndex = 8;
            this.L1.Text = "label1";
            // 
            // L2
            // 
            this.L2.AccessibleName = "Customer1";
            this.L2.AutoSize = true;
            this.L2.Location = new System.Drawing.Point(800, 175);
            this.L2.Name = "L2";
            this.L2.Size = new System.Drawing.Size(46, 17);
            this.L2.TabIndex = 16;
            this.L2.Text = "label1";
            // 
            // S2
            // 
            this.S2.AccessibleName = "Customer1";
            this.S2.AutoSize = true;
            this.S2.Location = new System.Drawing.Point(700, 175);
            this.S2.Name = "S2";
            this.S2.Size = new System.Drawing.Size(46, 17);
            this.S2.TabIndex = 15;
            this.S2.Text = "label1";
            // 
            // P2
            // 
            this.P2.AccessibleName = "Customer1";
            this.P2.AutoSize = true;
            this.P2.Location = new System.Drawing.Point(600, 175);
            this.P2.Name = "P2";
            this.P2.Size = new System.Drawing.Size(46, 17);
            this.P2.TabIndex = 14;
            this.P2.Text = "label1";
            // 
            // C2
            // 
            this.C2.AccessibleName = "Customer1";
            this.C2.AutoSize = true;
            this.C2.Location = new System.Drawing.Point(500, 175);
            this.C2.Name = "C2";
            this.C2.Size = new System.Drawing.Size(46, 17);
            this.C2.TabIndex = 13;
            this.C2.Text = "label1";
            // 
            // T2
            // 
            this.T2.AccessibleName = "Customer1";
            this.T2.AutoSize = true;
            this.T2.Location = new System.Drawing.Point(400, 175);
            this.T2.Name = "T2";
            this.T2.Size = new System.Drawing.Size(46, 17);
            this.T2.TabIndex = 12;
            this.T2.Text = "label1";
            // 
            // GA2
            // 
            this.GA2.AccessibleName = "Customer1";
            this.GA2.AutoSize = true;
            this.GA2.Location = new System.Drawing.Point(300, 175);
            this.GA2.Name = "GA2";
            this.GA2.Size = new System.Drawing.Size(46, 17);
            this.GA2.TabIndex = 11;
            this.GA2.Text = "label1";
            // 
            // RA2
            // 
            this.RA2.AccessibleName = "Customer1";
            this.RA2.AutoSize = true;
            this.RA2.Location = new System.Drawing.Point(200, 175);
            this.RA2.Name = "RA2";
            this.RA2.Size = new System.Drawing.Size(46, 17);
            this.RA2.TabIndex = 10;
            this.RA2.Text = "label1";
            // 
            // Customer2
            // 
            this.Customer2.AccessibleName = "Customer1";
            this.Customer2.AutoSize = true;
            this.Customer2.Location = new System.Drawing.Point(75, 175);
            this.Customer2.Name = "Customer2";
            this.Customer2.Size = new System.Drawing.Size(46, 17);
            this.Customer2.TabIndex = 9;
            this.Customer2.Text = "label1";
            // 
            // L3
            // 
            this.L3.AccessibleName = "Customer1";
            this.L3.AutoSize = true;
            this.L3.Location = new System.Drawing.Point(800, 250);
            this.L3.Name = "L3";
            this.L3.Size = new System.Drawing.Size(46, 17);
            this.L3.TabIndex = 24;
            this.L3.Text = "label1";
            // 
            // S3
            // 
            this.S3.AccessibleName = "Customer1";
            this.S3.AutoSize = true;
            this.S3.Location = new System.Drawing.Point(700, 250);
            this.S3.Name = "S3";
            this.S3.Size = new System.Drawing.Size(46, 17);
            this.S3.TabIndex = 23;
            this.S3.Text = "label1";
            // 
            // P3
            // 
            this.P3.AccessibleName = "Customer1";
            this.P3.AutoSize = true;
            this.P3.Location = new System.Drawing.Point(600, 250);
            this.P3.Name = "P3";
            this.P3.Size = new System.Drawing.Size(46, 17);
            this.P3.TabIndex = 22;
            this.P3.Text = "label1";
            // 
            // C3
            // 
            this.C3.AccessibleName = "Customer1";
            this.C3.AutoSize = true;
            this.C3.Location = new System.Drawing.Point(500, 250);
            this.C3.Name = "C3";
            this.C3.Size = new System.Drawing.Size(46, 17);
            this.C3.TabIndex = 21;
            this.C3.Text = "label1";
            // 
            // T3
            // 
            this.T3.AccessibleName = "Customer1";
            this.T3.AutoSize = true;
            this.T3.Location = new System.Drawing.Point(400, 250);
            this.T3.Name = "T3";
            this.T3.Size = new System.Drawing.Size(46, 17);
            this.T3.TabIndex = 20;
            this.T3.Text = "label1";
            // 
            // GA3
            // 
            this.GA3.AccessibleName = "Customer1";
            this.GA3.AutoSize = true;
            this.GA3.Location = new System.Drawing.Point(300, 250);
            this.GA3.Name = "GA3";
            this.GA3.Size = new System.Drawing.Size(46, 17);
            this.GA3.TabIndex = 19;
            this.GA3.Text = "label1";
            // 
            // RA3
            // 
            this.RA3.AccessibleName = "Customer1";
            this.RA3.AutoSize = true;
            this.RA3.Location = new System.Drawing.Point(200, 250);
            this.RA3.Name = "RA3";
            this.RA3.Size = new System.Drawing.Size(46, 17);
            this.RA3.TabIndex = 18;
            this.RA3.Text = "label1";
            // 
            // Customer3
            // 
            this.Customer3.AccessibleName = "Customer1";
            this.Customer3.AutoSize = true;
            this.Customer3.Location = new System.Drawing.Point(75, 250);
            this.Customer3.Name = "Customer3";
            this.Customer3.Size = new System.Drawing.Size(46, 17);
            this.Customer3.TabIndex = 17;
            this.Customer3.Text = "label1";
            // 
            // L4
            // 
            this.L4.AccessibleName = "Customer1";
            this.L4.AutoSize = true;
            this.L4.Location = new System.Drawing.Point(800, 325);
            this.L4.Name = "L4";
            this.L4.Size = new System.Drawing.Size(46, 17);
            this.L4.TabIndex = 32;
            this.L4.Text = "label1";
            // 
            // S4
            // 
            this.S4.AccessibleName = "Customer1";
            this.S4.AutoSize = true;
            this.S4.Location = new System.Drawing.Point(700, 325);
            this.S4.Name = "S4";
            this.S4.Size = new System.Drawing.Size(46, 17);
            this.S4.TabIndex = 31;
            this.S4.Text = "label1";
            // 
            // P4
            // 
            this.P4.AccessibleName = "Customer1";
            this.P4.AutoSize = true;
            this.P4.Location = new System.Drawing.Point(600, 325);
            this.P4.Name = "P4";
            this.P4.Size = new System.Drawing.Size(46, 17);
            this.P4.TabIndex = 30;
            this.P4.Text = "label1";
            // 
            // C4
            // 
            this.C4.AccessibleName = "Customer1";
            this.C4.AutoSize = true;
            this.C4.Location = new System.Drawing.Point(500, 325);
            this.C4.Name = "C4";
            this.C4.Size = new System.Drawing.Size(46, 17);
            this.C4.TabIndex = 29;
            this.C4.Text = "label1";
            // 
            // T4
            // 
            this.T4.AccessibleName = "Customer1";
            this.T4.AutoSize = true;
            this.T4.Location = new System.Drawing.Point(400, 325);
            this.T4.Name = "T4";
            this.T4.Size = new System.Drawing.Size(46, 17);
            this.T4.TabIndex = 28;
            this.T4.Text = "label1";
            // 
            // GA4
            // 
            this.GA4.AccessibleName = "Customer1";
            this.GA4.AutoSize = true;
            this.GA4.Location = new System.Drawing.Point(300, 325);
            this.GA4.Name = "GA4";
            this.GA4.Size = new System.Drawing.Size(46, 17);
            this.GA4.TabIndex = 27;
            this.GA4.Text = "label1";
            // 
            // RA4
            // 
            this.RA4.AccessibleName = "Customer1";
            this.RA4.AutoSize = true;
            this.RA4.Location = new System.Drawing.Point(200, 325);
            this.RA4.Name = "RA4";
            this.RA4.Size = new System.Drawing.Size(46, 17);
            this.RA4.TabIndex = 26;
            this.RA4.Text = "label1";
            // 
            // Customer4
            // 
            this.Customer4.AccessibleName = "Customer1";
            this.Customer4.AutoSize = true;
            this.Customer4.Location = new System.Drawing.Point(75, 325);
            this.Customer4.Name = "Customer4";
            this.Customer4.Size = new System.Drawing.Size(46, 17);
            this.Customer4.TabIndex = 25;
            this.Customer4.Text = "label1";
            // 
            // L5
            // 
            this.L5.AccessibleName = "Customer1";
            this.L5.AutoSize = true;
            this.L5.Location = new System.Drawing.Point(800, 400);
            this.L5.Name = "L5";
            this.L5.Size = new System.Drawing.Size(46, 17);
            this.L5.TabIndex = 40;
            this.L5.Text = "label1";
            // 
            // S5
            // 
            this.S5.AccessibleName = "Customer1";
            this.S5.AutoSize = true;
            this.S5.Location = new System.Drawing.Point(700, 400);
            this.S5.Name = "S5";
            this.S5.Size = new System.Drawing.Size(46, 17);
            this.S5.TabIndex = 39;
            this.S5.Text = "label1";
            // 
            // P5
            // 
            this.P5.AccessibleName = "Customer1";
            this.P5.AutoSize = true;
            this.P5.Location = new System.Drawing.Point(600, 400);
            this.P5.Name = "P5";
            this.P5.Size = new System.Drawing.Size(46, 17);
            this.P5.TabIndex = 38;
            this.P5.Text = "label1";
            // 
            // C5
            // 
            this.C5.AccessibleName = "Customer1";
            this.C5.AutoSize = true;
            this.C5.Location = new System.Drawing.Point(500, 400);
            this.C5.Name = "C5";
            this.C5.Size = new System.Drawing.Size(46, 17);
            this.C5.TabIndex = 37;
            this.C5.Text = "label1";
            // 
            // T5
            // 
            this.T5.AccessibleName = "Customer1";
            this.T5.AutoSize = true;
            this.T5.Location = new System.Drawing.Point(400, 400);
            this.T5.Name = "T5";
            this.T5.Size = new System.Drawing.Size(46, 17);
            this.T5.TabIndex = 36;
            this.T5.Text = "label1";
            // 
            // GA5
            // 
            this.GA5.AccessibleName = "Customer1";
            this.GA5.AutoSize = true;
            this.GA5.Location = new System.Drawing.Point(300, 400);
            this.GA5.Name = "GA5";
            this.GA5.Size = new System.Drawing.Size(46, 17);
            this.GA5.TabIndex = 35;
            this.GA5.Text = "label1";
            // 
            // RA5
            // 
            this.RA5.AccessibleName = "Customer1";
            this.RA5.AutoSize = true;
            this.RA5.Location = new System.Drawing.Point(200, 400);
            this.RA5.Name = "RA5";
            this.RA5.Size = new System.Drawing.Size(46, 17);
            this.RA5.TabIndex = 34;
            this.RA5.Text = "label1";
            // 
            // Customer5
            // 
            this.Customer5.AccessibleName = "Customer1";
            this.Customer5.AutoSize = true;
            this.Customer5.Location = new System.Drawing.Point(75, 400);
            this.Customer5.Name = "Customer5";
            this.Customer5.Size = new System.Drawing.Size(46, 17);
            this.Customer5.TabIndex = 33;
            this.Customer5.Text = "label1";
            // 
            // LT
            // 
            this.LT.AccessibleName = "Customer1";
            this.LT.AutoSize = true;
            this.LT.Location = new System.Drawing.Point(800, 475);
            this.LT.Name = "LT";
            this.LT.Size = new System.Drawing.Size(46, 17);
            this.LT.TabIndex = 48;
            this.LT.Text = "label1";
            // 
            // ST
            // 
            this.ST.AccessibleName = "Customer1";
            this.ST.AutoSize = true;
            this.ST.Location = new System.Drawing.Point(700, 475);
            this.ST.Name = "ST";
            this.ST.Size = new System.Drawing.Size(46, 17);
            this.ST.TabIndex = 47;
            this.ST.Text = "label1";
            // 
            // PT
            // 
            this.PT.AccessibleName = "Customer1";
            this.PT.AutoSize = true;
            this.PT.Location = new System.Drawing.Point(600, 475);
            this.PT.Name = "PT";
            this.PT.Size = new System.Drawing.Size(46, 17);
            this.PT.TabIndex = 46;
            this.PT.Text = "label1";
            // 
            // CT
            // 
            this.CT.AccessibleName = "Customer1";
            this.CT.AutoSize = true;
            this.CT.Location = new System.Drawing.Point(500, 475);
            this.CT.Name = "CT";
            this.CT.Size = new System.Drawing.Size(46, 17);
            this.CT.TabIndex = 45;
            this.CT.Text = "label1";
            // 
            // TT
            // 
            this.TT.AccessibleName = "Customer1";
            this.TT.AutoSize = true;
            this.TT.Location = new System.Drawing.Point(400, 475);
            this.TT.Name = "TT";
            this.TT.Size = new System.Drawing.Size(46, 17);
            this.TT.TabIndex = 44;
            this.TT.Text = "label1";
            // 
            // GAT
            // 
            this.GAT.AccessibleName = "Customer1";
            this.GAT.AutoSize = true;
            this.GAT.Location = new System.Drawing.Point(300, 475);
            this.GAT.Name = "GAT";
            this.GAT.Size = new System.Drawing.Size(46, 17);
            this.GAT.TabIndex = 43;
            this.GAT.Text = "label1";
            // 
            // RAT
            // 
            this.RAT.AccessibleName = "Customer1";
            this.RAT.AutoSize = true;
            this.RAT.Location = new System.Drawing.Point(200, 475);
            this.RAT.Name = "RAT";
            this.RAT.Size = new System.Drawing.Size(46, 17);
            this.RAT.TabIndex = 42;
            this.RAT.Text = "label1";
            // 
            // CustomerTotal
            // 
            this.CustomerTotal.AccessibleName = "Customer1";
            this.CustomerTotal.AutoSize = true;
            this.CustomerTotal.Location = new System.Drawing.Point(75, 475);
            this.CustomerTotal.Name = "CustomerTotal";
            this.CustomerTotal.Size = new System.Drawing.Size(53, 17);
            this.CustomerTotal.TabIndex = 41;
            this.CustomerTotal.Text = "---------";
            // 
            // Info1
            // 
            this.Info1.AccessibleName = "Customer1";
            this.Info1.AutoSize = true;
            this.Info1.Location = new System.Drawing.Point(75, 125);
            this.Info1.Name = "Info1";
            this.Info1.Size = new System.Drawing.Size(46, 17);
            this.Info1.TabIndex = 49;
            this.Info1.Text = "label1";
            // 
            // Info2
            // 
            this.Info2.AccessibleName = "Customer1";
            this.Info2.AutoSize = true;
            this.Info2.Location = new System.Drawing.Point(75, 200);
            this.Info2.Name = "Info2";
            this.Info2.Size = new System.Drawing.Size(46, 17);
            this.Info2.TabIndex = 50;
            this.Info2.Text = "label1";
            // 
            // Info3
            // 
            this.Info3.AccessibleName = "Customer1";
            this.Info3.AutoSize = true;
            this.Info3.Location = new System.Drawing.Point(75, 275);
            this.Info3.Name = "Info3";
            this.Info3.Size = new System.Drawing.Size(46, 17);
            this.Info3.TabIndex = 51;
            this.Info3.Text = "label1";
            // 
            // Info4
            // 
            this.Info4.AccessibleName = "Customer1";
            this.Info4.AutoSize = true;
            this.Info4.Location = new System.Drawing.Point(75, 350);
            this.Info4.Name = "Info4";
            this.Info4.Size = new System.Drawing.Size(46, 17);
            this.Info4.TabIndex = 52;
            this.Info4.Text = "label1";
            // 
            // Info5
            // 
            this.Info5.AccessibleName = "Customer1";
            this.Info5.AutoSize = true;
            this.Info5.Location = new System.Drawing.Point(75, 425);
            this.Info5.Name = "Info5";
            this.Info5.Size = new System.Drawing.Size(46, 17);
            this.Info5.TabIndex = 53;
            this.Info5.Text = "label1";
            // 
            // Reports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 553);
            this.Controls.Add(this.Info5);
            this.Controls.Add(this.Info4);
            this.Controls.Add(this.Info3);
            this.Controls.Add(this.Info2);
            this.Controls.Add(this.Info1);
            this.Controls.Add(this.LT);
            this.Controls.Add(this.ST);
            this.Controls.Add(this.PT);
            this.Controls.Add(this.CT);
            this.Controls.Add(this.TT);
            this.Controls.Add(this.GAT);
            this.Controls.Add(this.RAT);
            this.Controls.Add(this.CustomerTotal);
            this.Controls.Add(this.L5);
            this.Controls.Add(this.S5);
            this.Controls.Add(this.P5);
            this.Controls.Add(this.C5);
            this.Controls.Add(this.T5);
            this.Controls.Add(this.GA5);
            this.Controls.Add(this.RA5);
            this.Controls.Add(this.Customer5);
            this.Controls.Add(this.L4);
            this.Controls.Add(this.S4);
            this.Controls.Add(this.P4);
            this.Controls.Add(this.C4);
            this.Controls.Add(this.T4);
            this.Controls.Add(this.GA4);
            this.Controls.Add(this.RA4);
            this.Controls.Add(this.Customer4);
            this.Controls.Add(this.L3);
            this.Controls.Add(this.S3);
            this.Controls.Add(this.P3);
            this.Controls.Add(this.C3);
            this.Controls.Add(this.T3);
            this.Controls.Add(this.GA3);
            this.Controls.Add(this.RA3);
            this.Controls.Add(this.Customer3);
            this.Controls.Add(this.L2);
            this.Controls.Add(this.S2);
            this.Controls.Add(this.P2);
            this.Controls.Add(this.C2);
            this.Controls.Add(this.T2);
            this.Controls.Add(this.GA2);
            this.Controls.Add(this.RA2);
            this.Controls.Add(this.Customer2);
            this.Controls.Add(this.L1);
            this.Controls.Add(this.S1);
            this.Controls.Add(this.P1);
            this.Controls.Add(this.C1);
            this.Controls.Add(this.T1);
            this.Controls.Add(this.GA1);
            this.Controls.Add(this.RA1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Customer1);
            this.Name = "Reports";
            this.Text = "Reports";
            this.Controls.SetChildIndex(this.Customer1, 0);
            this.Controls.SetChildIndex(this.button1, 0);
            this.Controls.SetChildIndex(this.RA1, 0);
            this.Controls.SetChildIndex(this.GA1, 0);
            this.Controls.SetChildIndex(this.T1, 0);
            this.Controls.SetChildIndex(this.C1, 0);
            this.Controls.SetChildIndex(this.P1, 0);
            this.Controls.SetChildIndex(this.S1, 0);
            this.Controls.SetChildIndex(this.L1, 0);
            this.Controls.SetChildIndex(this.Customer2, 0);
            this.Controls.SetChildIndex(this.RA2, 0);
            this.Controls.SetChildIndex(this.GA2, 0);
            this.Controls.SetChildIndex(this.T2, 0);
            this.Controls.SetChildIndex(this.C2, 0);
            this.Controls.SetChildIndex(this.P2, 0);
            this.Controls.SetChildIndex(this.S2, 0);
            this.Controls.SetChildIndex(this.L2, 0);
            this.Controls.SetChildIndex(this.Customer3, 0);
            this.Controls.SetChildIndex(this.RA3, 0);
            this.Controls.SetChildIndex(this.GA3, 0);
            this.Controls.SetChildIndex(this.T3, 0);
            this.Controls.SetChildIndex(this.C3, 0);
            this.Controls.SetChildIndex(this.P3, 0);
            this.Controls.SetChildIndex(this.S3, 0);
            this.Controls.SetChildIndex(this.L3, 0);
            this.Controls.SetChildIndex(this.Customer4, 0);
            this.Controls.SetChildIndex(this.RA4, 0);
            this.Controls.SetChildIndex(this.GA4, 0);
            this.Controls.SetChildIndex(this.T4, 0);
            this.Controls.SetChildIndex(this.C4, 0);
            this.Controls.SetChildIndex(this.P4, 0);
            this.Controls.SetChildIndex(this.S4, 0);
            this.Controls.SetChildIndex(this.L4, 0);
            this.Controls.SetChildIndex(this.Customer5, 0);
            this.Controls.SetChildIndex(this.RA5, 0);
            this.Controls.SetChildIndex(this.GA5, 0);
            this.Controls.SetChildIndex(this.T5, 0);
            this.Controls.SetChildIndex(this.C5, 0);
            this.Controls.SetChildIndex(this.P5, 0);
            this.Controls.SetChildIndex(this.S5, 0);
            this.Controls.SetChildIndex(this.L5, 0);
            this.Controls.SetChildIndex(this.CustomerTotal, 0);
            this.Controls.SetChildIndex(this.RAT, 0);
            this.Controls.SetChildIndex(this.GAT, 0);
            this.Controls.SetChildIndex(this.TT, 0);
            this.Controls.SetChildIndex(this.CT, 0);
            this.Controls.SetChildIndex(this.PT, 0);
            this.Controls.SetChildIndex(this.ST, 0);
            this.Controls.SetChildIndex(this.LT, 0);
            this.Controls.SetChildIndex(this.Info1, 0);
            this.Controls.SetChildIndex(this.Info2, 0);
            this.Controls.SetChildIndex(this.Info3, 0);
            this.Controls.SetChildIndex(this.Info4, 0);
            this.Controls.SetChildIndex(this.Info5, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label Customer1;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.Label RA1;
        public System.Windows.Forms.Label GA1;
        public System.Windows.Forms.Label T1;
        public System.Windows.Forms.Label C1;
        public System.Windows.Forms.Label P1;
        public System.Windows.Forms.Label S1;
        public System.Windows.Forms.Label L1;
        public System.Windows.Forms.Label L2;
        public System.Windows.Forms.Label S2;
        public System.Windows.Forms.Label P2;
        public System.Windows.Forms.Label C2;
        public System.Windows.Forms.Label T2;
        public System.Windows.Forms.Label GA2;
        public System.Windows.Forms.Label RA2;
        public System.Windows.Forms.Label Customer2;
        public System.Windows.Forms.Label L3;
        public System.Windows.Forms.Label S3;
        public System.Windows.Forms.Label P3;
        public System.Windows.Forms.Label C3;
        public System.Windows.Forms.Label T3;
        public System.Windows.Forms.Label GA3;
        public System.Windows.Forms.Label RA3;
        public System.Windows.Forms.Label Customer3;
        public System.Windows.Forms.Label L4;
        public System.Windows.Forms.Label S4;
        public System.Windows.Forms.Label P4;
        public System.Windows.Forms.Label C4;
        public System.Windows.Forms.Label T4;
        public System.Windows.Forms.Label GA4;
        public System.Windows.Forms.Label RA4;
        public System.Windows.Forms.Label Customer4;
        public System.Windows.Forms.Label L5;
        public System.Windows.Forms.Label S5;
        public System.Windows.Forms.Label P5;
        public System.Windows.Forms.Label C5;
        public System.Windows.Forms.Label T5;
        public System.Windows.Forms.Label GA5;
        public System.Windows.Forms.Label RA5;
        public System.Windows.Forms.Label Customer5;
        public System.Windows.Forms.Label LT;
        public System.Windows.Forms.Label ST;
        public System.Windows.Forms.Label PT;
        public System.Windows.Forms.Label CT;
        public System.Windows.Forms.Label TT;
        public System.Windows.Forms.Label GAT;
        public System.Windows.Forms.Label RAT;
        public System.Windows.Forms.Label CustomerTotal;
        public System.Windows.Forms.Label Info1;
        public System.Windows.Forms.Label Info2;
        public System.Windows.Forms.Label Info3;
        public System.Windows.Forms.Label Info4;
        public System.Windows.Forms.Label Info5;
    }
}