﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fruit_Manager_V1._0
{
    public partial class Reports : Form3
    {
        //counters
        public static int entryNumber = 0;
        public static int i;

        //passing of Variables
        public static string[] customer = new string[6];
        public static string[] info = new string[6];
        public static string[] CustomerTotal = new string[6];

        //totals for price and boxes
        public static int OverallTotal;
        public static int BoxesTotal;

        public class Fruit
        {
            public virtual void FruitCost()
            {
                int num;
            }
        } 
        
        public class RedApples : Fruit
        {
            public static string[] ra = new string[6];
            public override void FruitCost()
            {
                int num = 32;
            }
            public static int ratotal = 0;
        }

        public class GoldenApples : Fruit
        {
            public static string[] ga = new string[6];
            public override void FruitCost()
            {
                int num = 34;
            }
            public static int gatotal = 0;
        }

        public class Tangerines : Fruit
        {
            public static string[] t = new string[6];
            public override void FruitCost()
            {
                int num = 40;
            }
            public static int ttotal = 0;
        }

        public class Clemitines : Fruit
        {
            public static string[] c = new string[6];
            public override void FruitCost()
            {
                int num = 14;
            }
            public static int ctotal = 0;
        }

        public class Pears : Fruit
        {
            public static string[] p = new string[6];
            public override void FruitCost()
            {
                int num = 30;
            }
            public static int ptotal = 0;
        }

        public class SmallBox : Fruit
        {
            public static string[] s = new string[6];
            public override void FruitCost()
            {
                int num = 24;
            }
            public static int stotal = 0;
        }

        public class LargeBox : Fruit
        {
            public static string[] l = new string[6];
            public override void FruitCost()
            {
                int num = 36;
            }
            public static int ltotal = 0;
        }


        public Reports()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Customer1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            for(i=1; i<= entryNumber; i++)
            {

                if(i == 1)
                {
                    string myString = customer[i].ToString();
                    Customer1.Text = myString;

                    string myString1 = info[i].ToString();
                    Info1.Text = myString1;

                    string myString2 = RedApples.ra[i].ToString();
                    RA1.Text = myString2;
                    myString2 = RedApples.ratotal.ToString();
                    RAT.Text = myString2;

                    string myString3 = GoldenApples.ga[i].ToString();
                    GA1.Text = myString3;
                    myString3 = GoldenApples.gatotal.ToString();
                    GAT.Text = myString3;

                    string myString4 = Tangerines.t[i].ToString();
                    T1.Text = myString4;
                    myString4 = Tangerines.ttotal.ToString();
                    TT.Text = myString4;

                    string myString5 = Clemitines.c[i].ToString();
                    C1.Text = myString5;
                    myString5 = Clemitines.ctotal.ToString();
                    CT.Text = myString5;

                    string myString6 = Pears.p[i].ToString();
                    P1.Text = myString6;
                    myString6 = Pears.ptotal.ToString();
                    PT.Text = myString6;

                    string myString7 = SmallBox.s[i].ToString();
                    S1.Text = myString7;
                    myString7 = SmallBox.stotal.ToString();
                    ST.Text = myString7;

                    string myString8 = LargeBox.l[i].ToString();
                    L1.Text = myString8;
                    myString8 = LargeBox.ltotal.ToString();
                    LT.Text = myString8;

                    string myString9 = CustomerTotal[i].ToString();
                    Customer1Cost.Text = myString9;

                    string myString10 = OverallTotal.ToString();
                    OTotal.Text = myString10;
                    myString10 = BoxesTotal.ToString();
                    BTotal.Text = myString10;
                }

                else if (i == 2)
                {
                    string myString = customer[i].ToString();
                    Customer2.Text = myString;

                    string myString1 = info[i].ToString();
                    Info2.Text = myString1;

                    string myString2 = RedApples.ra[i].ToString();
                    RA2.Text = myString2;

                    string myString3 = GoldenApples.ga[i].ToString();
                    GA2.Text = myString3;

                    string myString4 = Tangerines.t[i].ToString();
                    T2.Text = myString4;

                    string myString5 = Clemitines.c[i].ToString();
                    C2.Text = myString5;

                    string myString6 = Pears.p[i].ToString();
                    P2.Text = myString6;

                    string myString7 = SmallBox.s[i].ToString();
                    S2.Text = myString7;

                    string myString8 = LargeBox.l[i].ToString();
                    L2.Text = myString8;
                }
                else if (i == 3)
                {
                    string myString = customer[i].ToString();
                    Customer3.Text = myString;

                    string myString1 = info[i].ToString();
                    Info3.Text = myString1;

                    string myString2 = RedApples.ra[i].ToString();
                    RA3.Text = myString2;

                    string myString3 = GoldenApples.ga[i].ToString();
                    GA3.Text = myString3;

                    string myString4 = Tangerines.t[i].ToString();
                    T3.Text = myString4;

                    string myString5 = Clemitines.c[i].ToString();
                    C3.Text = myString5;

                    string myString6 = Pears.p[i].ToString();
                    P3.Text = myString6;

                    string myString7 = SmallBox.s[i].ToString();
                    S3.Text = myString7;

                    string myString8 = LargeBox.l[i].ToString();
                    L3.Text = myString8;
                }
                else if (i == 4)
                {
                    string myString = customer[i].ToString();
                    Customer4.Text = myString;

                    string myString1 = info[i].ToString();
                    Info4.Text = myString1;

                    string myString2 = RedApples.ra[i].ToString();
                    RA4.Text = myString2;

                    string myString3 = GoldenApples.ga[i].ToString();
                    GA4.Text = myString3;

                    string myString4 = Tangerines.t[i].ToString();
                    T4.Text = myString4;

                    string myString5 = Clemitines.c[i].ToString();
                    C4.Text = myString5;

                    string myString6 = Pears.p[i].ToString();
                    P4.Text = myString6;

                    string myString7 = SmallBox.s[i].ToString();
                    S4.Text = myString7;

                    string myString8 = LargeBox.l[i].ToString();
                    L4.Text = myString8;
                }
                else if (i == 5)
                {
                    string myString = customer[i].ToString();
                    Customer5.Text = myString;

                    string myString1 = info[i].ToString();
                    Info5.Text = myString1;

                    string myString2 = RedApples.ra[i].ToString();
                    RA5.Text = myString2;

                    string myString3 = GoldenApples.ga[i].ToString();
                    GA5.Text = myString3;

                    string myString4 = Tangerines.t[i].ToString();
                    T5.Text = myString4;

                    string myString5 = Clemitines.c[i].ToString();
                    C5.Text = myString5;

                    string myString6 = Pears.p[i].ToString();
                    P5.Text = myString6;

                    string myString7 = SmallBox.s[i].ToString();
                    S5.Text = myString7;

                    string myString8 = LargeBox.l[i].ToString();
                    L5.Text = myString8;
                }
            }
        }
    }
}
